# PM Career DNA — Codex 改正与素材包

先读 `START_HERE_PM_ONLY_NOTE.md`，再读 `CODEX_CORRECTION_STANDARD.md`。这是一个交付包，不是两份用户结果。

## 包含

- `CODEX_CORRECTION_STANDARD.md`：单份输出、防遮挡、PM 角色→能力、配色、人物选择与完整验收标准。
- `assets/pm-characters-24.png`：24 个人物的内部透明图集；统一暖杏色卡通肤色和中性造型，变化仅在发型、服装、姿势、表情和道具。
- `assets/pm-icons-24.png`：24 个互联网 PM 图标的内部透明图集。
- `manifest.json`：每个 sprite 的 ID、源坐标和用途。
- `role-taxonomy.json`：15 种 PM 功能类型与参考图六种 archetype 的映射；映射仍须证据支持。
- `themes.json`：6 种批准配色，含蓝、绿、黄、桃、青绿与浅紫。
- `sprite-reference.js`：读取 manifest 指定素材的 SVG 调用示例。
- `asset-catalog.html`：本地可打开的内部素材目录，用于逐格检查；不是网站结果页。
- `references/`：用户提供过的两张构图/角色参考图。

## 当前状态

网站的紧急双图 bug 已单独修复：导出 canvas 移出 DOM，不能再被 CSS 显示成第二张图。

本包的 PM 专项角色归纳、24 人物、24 图标与随机主题选择尚未接入网站。Codex 应按标准实现并验收，不能将“素材已生成”误报为“产品已接入”。

人物和图标原生都是 6×4 图集、1536×1024，每格 256×256，带 alpha 透明通道和柔阴影。适合小尺寸组件。需要更大的精细高清母图时，应逐个精修/生成；单纯插值放大不会增加细节。上线前要检查裁切、边缘残影与安全边距。

## 给 Codex 的执行顺序

1. 复现双图问题，检查所有实际可见结果；保留 DOM 外的导出画布。
2. 以两张参考图为依据，建立前景安全区与碰撞检测，移除互相遮挡的图标/贴纸。
3. 调整角色抽取为 PM 功能类型，能力单独有证据地归纳。
4. 从 manifest 选择人物与图标，从 themes 选择配色。新结果选一次，缩放/下载不重新选。
5. 仅渲染一个结果根节点，导出同一内容和 variant 的单个 PNG。
6. 完成正文列出的视觉与自动验收后再发布。

用户数据政策与现有调用限额保持不变。不要把图集、六宫格参考图或素材目录作为第二张用户产出。

## 白底人物总览

`previews/pm-characters-24-white.png` 是按用户要求制作的白底人物总览，可单独打开或下载。正式拼图继续调用 `assets/pm-characters-24.png` 的透明素材，以避免白色矩形遮挡其他背景主题。二者是同一人物库的检视/调用用途，不是两份用户 PM Career DNA 结果。

## PM-only 品牌与元素

首版品牌为 **PM Career DNA**，只面向互联网/科技产品经理。其他职业暂不 target，待 PM 体验充分打磨后另行评估。

`brand/pm-career-dna-logo-white.png` 是新设计的 PM＋DNA Logo。`PRODUCT_ELEMENTS_INVENTORY.md` 列出 24 个已设计产品元素及适用角色。所有用户可见品牌、结果图标题、按钮和下载文件名的修改表在 `START_HERE_PM_ONLY_NOTE.md`。这些是待 Codex 集成的规范与素材，不代表网站已全部换名上线。

// Reference integration only. Consume trusted local manifest entries, not model URLs.
export function createSprite(entry, options = {}) {
  const ns = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(ns, 'svg');
  const image = document.createElementNS(ns, 'image');
  const box = entry.source_rect;
  svg.setAttribute('viewBox', `${box.x} ${box.y} ${box.width} ${box.height}`);
  svg.setAttribute('width', options.width || 128);
  svg.setAttribute('height', options.height || 128);
  svg.setAttribute('overflow', 'hidden');
  svg.setAttribute('role', 'img');
  svg.setAttribute('aria-label', options.label || entry.semantic || 'Career illustration');
  image.setAttribute('href', entry.atlas);
  image.setAttribute('width', '1536');
  image.setAttribute('height', '1024');
  svg.append(image);
  return svg;
}
// For export, embed each atlas once in SVG defs as an image and reference it by ID.
// Validate crop edges; do not display the entire atlas as the final user map.
// Select variant once per generation and pass it to BOTH preview and export.
// const exportCanvas = document.createElement('canvas'); // never append to DOM
